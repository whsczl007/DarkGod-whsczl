﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 主城地图数据
/// </summary>
public class MainCityMap : MonoBehaviour
{
    public Transform[] NpcPosTrans;

}
